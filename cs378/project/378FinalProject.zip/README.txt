README
1.Run decisiontree.py
2.Output file will generate