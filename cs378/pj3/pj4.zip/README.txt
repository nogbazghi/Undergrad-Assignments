/* THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS. William Seery and Nahom Ogbazghi */

To run the file, just have the two input files in the correct folder, 'file1.txt' and 'file2.txt'.
Then select the correct input file name, k value, and output file name.
To change the input file, change the name in line 5 of the code from 'file1.txt' to 'file2.txt', change the output file name, change the code in line 6, to change the k value, change the code in line 7.
The name of the output file is 'output.txt'. 
We included the code for our program that we used to pre process the data, but you don't need to use it because we already ran it on the dataset. 