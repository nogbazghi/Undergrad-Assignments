README:
Instructions:
1.Open apriori.py
2.Hard code input filename, k size, and ouput filename
3.Execute file